lf <- list.files()

rgx <- "VEST_0110_M5"
lf <- lf[grepl(rgx, lf)]

exp <- list()
for (lfile in lf) {
  cat(lfile,"\n")
  load(lfile)

  names(RESULTS) <- paste0("TS",1:length(RESULTS))
  exp <- c(exp, RESULTS)
}

exp <- exp[!sapply(exp,is.null)]
exp <- exp[!duplicated(names(exp))]
length(exp)
FINALRESULTS <- exp

#

#
# library(forecast)
# load("data/datasets.rdata")
# a<-sapply(ts_list,nsdiffs)
# FINALRESULTS<-FINALRESULTS[a==1]

save(FINALRESULTS, file = "VEST_0210_M5.rdata")
